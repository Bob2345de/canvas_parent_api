# Canvas Parent API

An async wrapper for the [Canvas LMS API](https://canvas.instructure.com/doc/api/) from Instructure, built for parent (observer) accounts. It returns the data a parent needs to keep an eye on how each child is doing across their courses.

The types of objects that can be returned include:
 - Observees (Students)
 - Courses
 - Assignments
 - Submissions
 - Announcements
 - Calendar Events
 - Assignment Groups (grade categories)
 - Teachers
 - Modules (with progress)
 - To-Do Items (outstanding assignments/quizzes)
 - Activity Stream (recent activity feed)

This module is the API layer that powers the **Canvas Parent Monitor** tool for Open WebUI, but it is a standalone library you can use in your own Python projects as well.

Author: Me

## Installing

To install the module from this source folder:
```python
python3 -m pip install .
```

Runtime dependencies (`aiohttp`, `pydantic`) install automatically. If you want an offline install, build a wheel with `py -m pip wheel . --no-deps -w dist` and install that instead.

### Get API Token
If you are a parent, you will have a Canvas Parent account.  To get an API token, you must sign into the Canvas Parent application from a web browser.  This is typically using: https://<yourdistrict>.instructure.com/login/canvas

Once you have signed into your account, navigate to Account > Settings.

Under "Approved Integrations" click "+ New Access Token" to create a new API Token.

Enter a Purpose and Expiration date (blank for no expiration).

Be sure to save your API token, as you will have to generate a new token if this is lost.

### Usage
Example usage to get students, printing names:
```python
import asyncio
from canvas_parent_api import Canvas

base_url = "https://school.instructure.com"
api_token = "randomstringthatisntreallyatoken"

async def get_students():
	client = Canvas(f"{base_url}",f"{api_token}")
	return await client.observees()

students = asyncio.run(get_students())

for student in students:
	print(student.name)
```

### Available Methods
All methods are async and return model objects with properties matching the Canvas API response fields (each object supports `.as_dict()` and `.tojson()`).

```python
client = Canvas(base_url, api_token)

# Students
await client.observees()

# Courses for a student (defaults to currently active enrollments only)
await client.courses(student_id)

# Past / finished courses from previous school years.
# enrollment_state accepts "active", "invited_or_pending" or "completed".
# Pass None to let Canvas apply its own default, which mixes active and
# concluded enrollments and therefore returns previous school years too.
await client.courses(student_id, enrollment_state="completed")

# Single course incl. syllabus_body / public_description
await client.course(course_id)

# Assignments for a student in a course
await client.assignments(student_id, course_id)

# Single assignment with submission details (grade, feedback via rubric/submission)
await client.assignment(course_id, assignment_id)

# Submissions for a student in a course
await client.submissions(student_id, course_id)

# Recent teacher announcements for a course (default: last 7 days)
await client.announcements(course_id, days_back=7)

# Upcoming calendar events for a student (default: next 14 days)
# event_type can be "event" or "assignment"
await client.calendar_events(student_id, days_ahead=14, event_type="event")

# Assignment groups (grade categories such as Homework, Quizzes, Tests)
await client.assignment_groups(course_id)

# Teachers for a course (name, email, avatar)
await client.teachers(course_id)

# Modules with items and per-student completion state
await client.modules(course_id, student_id)

# Recent activity feed for the current (parent) user
await client.activity_stream(only_active_courses=True)

# To-Do list (across all courses) for a specific student.
# GET /api/v1/users/{student_id}/todo — a concrete user id is required
# ('self' is intentionally rejected).
await client.todo(student_id)

# To-Do list scoped to a single course
await client.course_todo(course_id)
```

Note: Attendance (Roll Call) is not available through the public Canvas REST API (it is a separate LTI tool), so it is not supported by this module.

### Patch Notes

 - 0.0.32:
- Follow-up hardening for `canvas_get_calendar_events`. The planner item `submissions` field is *still* not a stable shape: besides a list it can come back as an empty string or another scalar, so `PlannerItemResponse.submissions` is now typed `Optional[Any]` and `PlannerItem` normalizes every shape (dict, list, string, etc.) to a dict defensively. No Canvas `submissions` value can fail validation or crash the calendar tool anymore.

 - 0.0.31:
- Fixed the intermittent "Some data could not be retrieved / value is not a valid dict (type=type_error.dict)" error in `canvas_get_calendar_events`. Canvas returns the planner item `submissions` field as a dict for some items but as a list (array of submission objects) for others; `PlannerItemResponse.submissions` previously required a dict, so any item with a list-form `submissions` failed the whole response. It now accepts both shapes and `PlannerItem` normalizes a list to a single submission dict.

 - 0.0.30:
- Fixed planner item parsing: Canvas returns planner items with the name/points nested under `plannable` and the date under `plannable_date` / kind under `plannable_type`. `PlannerItem.name/date/type/points_possible` now read the real schema (previously they read non-existent flat fields, so the calendar tool showed "None — unknown date"). `submitted` also handles the planner endpoint's boolean `submissions.submitted` flag.

 - 0.0.29:
- Added the Planner API: `await client.planner_items(user_id, start_date=..., end_date=..., context_codes=[...], observed_user_id=..., filter=...)` calls `GET /api/v1/users/:user_id/planner/items` (the data behind the Canvas "My Planner" dashboard). Returns `PlannerItem` objects with `name`, `date`/`due_at`, `type`, `context_name`, `course_id`, `points_possible`, `html_url` and submission completion state (`submitted`, `marked_complete`).

 - 0.0.28:
- Every HTTP request to the Canvas API is now written to a text log (the call URL, masked token, caller label, response status + body, and timestamps). Default log path is `/app/backend/data/canvas_api.log` (the Open WebUI data dir, volume-mounted to the host); override with `CANVAS_API_LOG_FILE`, and cap the logged response size with `CANVAS_API_LOG_MAX_BODY` (default 20000 chars).
- `Canvas(base_url, api_key, ..., label="Niclas")` / `CanvasApiClient(..., label=...)` optionally tags log entries with a caller label.

 - 0.0.27:
- `todo(user_id)` now requires a concrete student user id (calls `GET /api/v1/users/{user_id}/todo`); `'self'` is rejected so the to-do list always targets a specific student

 - 0.0.26:
- Added To-Do List endpoints: `todo()` (global, across all courses, `GET /api/v1/users/:user_id/todo`) and `course_todo(course_id)` (course-specific, `GET /api/v1/courses/:course_id/todo`)

 - 0.0.25:
- `courses()` now defaults to `enrollment_state="active"` so concluded enrollments from previous school years are no longer returned; pass `enrollment_state="completed"` for past courses or `None` for the Canvas default
- Observees, Courses, Assignments and Submissions now follow every pagination page instead of only the first two

 - 0.0.24:
- Added Announcements, Calendar Events, single Assignment details, Assignment Groups, single Course (syllabus), Teachers, Modules (progress), and Activity Stream endpoints

 - 0.0.12:
    - Added pagination support to automatically paginate to end of available requests

 - 0.0.9:
- Added Submissions
